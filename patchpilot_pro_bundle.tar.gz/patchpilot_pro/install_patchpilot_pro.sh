#!/bin/bash

set -e

echo "=== PatchPilot Pro Installer ==="

APP_DIR="/opt/patchpilot_pro"
VENV_DIR="$APP_DIR/venv"
SERVICE_DIR="/etc/systemd/system"
NGINX_CONF="/etc/nginx/conf.d/patchpilot.conf"

# Create application directory
sudo mkdir -p $APP_DIR
sudo cp -r patchpilot_pro/* $APP_DIR
cd $APP_DIR

# Install required system packages
echo "[+] Installing system dependencies..."
sudo dnf install -y python3 python3-venv python3-pip nginx policycoreutils-python-utils


# PostgreSQL setup
echo "[+] Installing and configuring PostgreSQL..."
sudo dnf install -y postgresql-server postgresql-contrib
sudo postgresql-setup --initdb
sudo systemctl enable postgresql
sudo systemctl start postgresql

sudo -u postgres psql -c "CREATE USER patchpilot_user WITH PASSWORD 'securepassword';"
sudo -u postgres psql -c "CREATE DATABASE patchpilot_db OWNER patchpilot_user;"
echo "host all  all    127.0.0.1/32  trust" | sudo tee -a /var/lib/pgsql/data/pg_hba.conf
sudo systemctl restart postgresql

# Set up Python virtual environment
echo "[+] Setting up Python virtual environment..."
python3 -m venv $VENV_DIR
source $VENV_DIR/bin/activate
pip install flask gunicorn

# Set permissions
sudo chown -R $USER:$USER $APP_DIR

# Copy systemd services
echo "[+] Installing systemd services..."
sudo cp $APP_DIR/systemd/patchpilot.service $SERVICE_DIR
sudo cp $APP_DIR/systemd/patchpilot.timer $SERVICE_DIR
sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable patchpilot.service
sudo systemctl enable patchpilot.timer


# Install Node.js for React frontend
echo "[+] Installing Node.js..."
sudo dnf module install -y nodejs:18

# Build React frontend
echo "[+] Building React frontend..."
cd $APP_DIR/web
npm install
npm run build

# Move React static files to a public directory
echo "[+] Deploying frontend to /var/www/patchpilot..."
sudo mkdir -p /var/www/patchpilot
sudo cp -r dist/* /var/www/patchpilot/

# Setup NGINX
echo "[+] Configuring NGINX for HTTPS (port 443)..."
sudo cp $APP_DIR/nginx/patchpilot.conf $NGINX_CONF
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/patchpilot.key \
  -out /etc/ssl/certs/patchpilot.crt \
  -subj "/C=US/ST=PatchPilot/L=PatchPilot/O=PatchPilot/OU=IT Department/CN=patchpilot.local"

sudo systemctl enable nginx
sudo systemctl restart nginx

echo "[✓] Installation complete! PatchPilot Pro is live on https://<your-server>"
