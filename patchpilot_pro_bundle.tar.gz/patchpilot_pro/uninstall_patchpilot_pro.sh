#!/bin/bash

echo "=== PatchPilot Pro Uninstaller ==="

APP_DIR="/opt/patchpilot_pro"
SERVICE_DIR="/etc/systemd/system"
NGINX_CONF="/etc/nginx/conf.d/patchpilot.conf"

# Stop services
echo "[+] Stopping services..."
sudo systemctl stop patchpilot.service || true
sudo systemctl stop patchpilot.timer || true
sudo systemctl disable patchpilot.service || true
sudo systemctl disable patchpilot.timer || true

# Remove systemd service files
sudo rm -f $SERVICE_DIR/patchpilot.service
sudo rm -f $SERVICE_DIR/patchpilot.timer
sudo systemctl daemon-reload

# Remove NGINX config
echo "[+] Removing NGINX configuration..."
sudo rm -f $NGINX_CONF
sudo systemctl restart nginx

# Remove app directory
echo "[+] Deleting application files..."
sudo rm -rf $APP_DIR

echo "[✓] PatchPilot Pro successfully uninstalled."
