
import subprocess
import json

def scan_system():
    result = subprocess.run(['dnf', 'check-update'], capture_output=True, text=True)
    updates = result.stdout.strip().split('\n')
    patch_list = []
    for line in updates:
        if line and not line.startswith("Last metadata expiration"):
            parts = line.split()
            if len(parts) >= 3:
                patch_list.append({"package": parts[0], "version": parts[1], "repo": parts[2]})
    return patch_list

if __name__ == "__main__":
    patches = scan_system()
    print(json.dumps({"status": "ok", "patches": patches}))
