
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(16), nullable=False)  # admin, operator, viewer

class PatchPolicy(db.Model):
    __tablename__ = 'patch_policies'
    id = db.Column(db.Integer, primary_key=True)
    group_name = db.Column(db.String(64), nullable=False)
    allowlist = db.Column(db.Text)  # JSON string of regex patterns
    blocklist = db.Column(db.Text)  # JSON string of regex patterns

class ScanResult(db.Model):
    __tablename__ = 'scan_results'
    id = db.Column(db.Integer, primary_key=True)
    host = db.Column(db.String(128))
    patches = db.Column(db.Text)  # JSON string
    timestamp = db.Column(db.DateTime)
    group = db.Column(db.String(64))
    compliant = db.Column(db.Boolean)

class Schedule(db.Model):
    __tablename__ = 'schedules'
    id = db.Column(db.Integer, primary_key=True)
    job_type = db.Column(db.String(16))  # scan or deploy
    target_group = db.Column(db.String(64))
    time = db.Column(db.String(64))  # cron-like format or time string
    created_by = db.Column(db.String(64))
