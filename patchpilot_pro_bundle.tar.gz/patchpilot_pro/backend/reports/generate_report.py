
import json
from datetime import datetime

def generate_report(data):
    report = {
        "timestamp": datetime.utcnow().isoformat(),
        "total_patches": len(data.get("patches", [])),
        "patches": data.get("patches", [])
    }
    with open("backend/reports/last_report.json", "w") as f:
        json.dump(report, f, indent=2)

if __name__ == "__main__":
    import subprocess
    result = subprocess.run(["python3", "backend/scanners/scan_patches.py"], capture_output=True, text=True)
    data = json.loads(result.stdout)
    generate_report(data)
