
from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import json
from models import db, User, PatchPolicy, ScanResult, Schedule

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default_secret')

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for("dashboard"))
        return "Invalid credentials", 401
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    return render_template("index.html", user=current_user)

@app.route("/api/scan", methods=["GET"])
@login_required
def scan():
    if current_user.role not in ["admin", "operator"]:
        return "Unauthorized", 403
    result = os.popen("python3 backend/scanners/scan_patches.py").read()
    patches = json.loads(result).get("patches", [])
    compliant = apply_policy(current_user.username, patches)
    scan = ScanResult(
        host="localhost",
        patches=json.dumps(patches),
        timestamp=datetime.utcnow(),
        group="default",
        compliant=compliant
    )
    db.session.add(scan)
    db.session.commit()
    return jsonify({"status": "ok", "patches": patches, "compliant": compliant})

@app.route("/api/report")
@login_required
def report():
    results = ScanResult.query.order_by(ScanResult.timestamp.desc()).limit(10).all()
    return jsonify([
        {
            "host": r.host,
            "patches": json.loads(r.patches),
            "timestamp": r.timestamp.isoformat(),
            "group": r.group,
            "compliant": r.compliant
        } for r in results
    ])

@app.route("/api/export/<fmt>")
@login_required
def export(fmt):
    import csv
    from flask import Response
    results = ScanResult.query.all()
    if fmt == "csv":
        output = "host,timestamp,group,compliant\n"
        for r in results:
            output += f"{r.host},{r.timestamp},{r.group},{r.compliant}\n"
        return Response(output, mimetype="text/csv")
    elif fmt == "json":
        return jsonify([
            {
                "host": r.host,
                "patches": json.loads(r.patches),
                "timestamp": r.timestamp.isoformat(),
                "group": r.group,
                "compliant": r.compliant
            } for r in results
        ])
    return "Unsupported format", 400

def apply_policy(username, patches):
    # Basic placeholder logic; extend as needed
    policy = PatchPolicy.query.filter_by(group_name="default").first()
    if not policy:
        return True
    blocked = json.loads(policy.blocklist or "[]")
    for patch in patches:
        for rule in blocked:
            if rule.lower() in patch['package'].lower():
                return False
    return True

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run()


@app.route("/admin", methods=["GET"])
@login_required
def admin_panel():
    if current_user.role != "admin":
        return "Unauthorized", 403
    policy = PatchPolicy.query.filter_by(group_name="default").first()
    if not policy:
        policy = PatchPolicy(group_name="default", allowlist="[]", blocklist="[]")
        db.session.add(policy)
        db.session.commit()
    schedules = Schedule.query.all()
    return render_template("admin.html", user=current_user, policy=policy, schedules=schedules)

@app.route("/admin/policy", methods=["POST"])
@login_required
def update_policy():
    if current_user.role != "admin":
        return "Unauthorized", 403
    policy = PatchPolicy.query.filter_by(group_name="default").first()
    if not policy:
        policy = PatchPolicy(group_name="default")
    policy.allowlist = request.form.get("allowlist", "[]")
    policy.blocklist = request.form.get("blocklist", "[]")
    db.session.add(policy)
    db.session.commit()
    return redirect(url_for("admin_panel"))

@app.route("/admin/schedule", methods=["POST"])
@login_required
def add_schedule():
    if current_user.role != "admin":
        return "Unauthorized", 403
    sched = Schedule(
        job_type=request.form["job_type"],
        target_group=request.form["target_group"],
        time=request.form["time"],
        created_by=current_user.username
    )
    db.session.add(sched)
    db.session.commit()
    return redirect(url_for("admin_panel"))


@app.route("/admin/users")
@login_required
def manage_users():
    if current_user.role != "admin":
        return "Unauthorized", 403
    users = User.query.all()
    return render_template("user_list.html", users=users)

@app.route("/admin/users/add", methods=["POST"])
@login_required
def add_user():
    if current_user.role != "admin":
        return "Unauthorized", 403
    from werkzeug.security import generate_password_hash
    new_user = User(
        username=request.form["username"],
        password=generate_password_hash(request.form["password"]),
        role=request.form["role"]
    )
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for("manage_users"))

@app.route("/admin/users/delete", methods=["POST"])
@login_required
def delete_user():
    if current_user.role != "admin":
        return "Unauthorized", 403
    uid = int(request.form["user_id"])
    if uid == current_user.id:
        return "Cannot delete yourself", 400
    User.query.filter_by(id=uid).delete()
    db.session.commit()
    return redirect(url_for("manage_users"))
