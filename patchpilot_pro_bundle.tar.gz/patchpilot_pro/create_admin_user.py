#!/usr/bin/env python3

import os
from getpass import getpass
from werkzeug.security import generate_password_hash
from flask import Flask
from backend.models import db, User

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default')

db.init_app(app)

with app.app_context():
    db.create_all()
    username = input("Enter admin username: ")
    password = getpass("Enter password: ")
    hash_pw = generate_password_hash(password)
    if User.query.filter_by(username=username).first():
        print("User already exists.")
    else:
        admin = User(username=username, password=hash_pw, role="admin")
        db.session.add(admin)
        db.session.commit()
        print(f"Admin user '{username}' created.")
