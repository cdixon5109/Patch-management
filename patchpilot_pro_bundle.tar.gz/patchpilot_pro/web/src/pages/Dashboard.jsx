
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis, Legend, ResponsiveContainer } from 'recharts'

const COLORS = ['#00C49F', '#FF8042']

export default function Dashboard() {
  const [reportData, setReportData] = useState([])
  const [complianceStats, setComplianceStats] = useState({ compliant: 0, noncompliant: 0 })

  useEffect(() => {
    axios.get('/api/report').then(res => {
      const data = res.data
      setReportData(data)
      const compliant = data.filter(item => item.compliant).length
      const noncompliant = data.length - compliant
      setComplianceStats({ compliant, noncompliant })
    })
  }, [])

  const compliancePieData = [
    { name: 'Compliant', value: complianceStats.compliant },
    { name: 'Non-Compliant', value: complianceStats.noncompliant }
  ]

  const patchTrendData = reportData.map(r => ({
    timestamp: r.timestamp.split('T')[0],
    count: r.patches.length
  }))

  return (
    <div className="p-6 space-y-8">
      <h1 className="text-3xl font-bold">PatchPilot Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded p-4 shadow">
          <h2 className="text-xl font-semibold mb-2">Compliance Overview</h2>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={compliancePieData} dataKey="value" nameKey="name" outerRadius={80} label>
                {compliancePieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded p-4 shadow">
          <h2 className="text-xl font-semibold mb-2">Patch Volume Over Time</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={patchTrendData}>
              <XAxis dataKey="timestamp" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#8884d8" name="Patches" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded p-4 shadow mt-6">
        <h2 className="text-xl font-semibold mb-2">Latest Scan Results</h2>
        <table className="w-full table-auto border-collapse">
          <thead>
            <tr>
              <th className="border p-2">Host</th>
              <th className="border p-2">Group</th>
              <th className="border p-2">Time</th>
              <th className="border p-2">Compliance</th>
              <th className="border p-2">Patch Count</th>
            </tr>
          </thead>
          <tbody>
            {reportData.map((r, i) => (
              <tr key={i} className="text-center">
                <td className="border p-2">{r.host}</td>
                <td className="border p-2">{r.group}</td>
                <td className="border p-2">{r.timestamp.split('T')[0]}</td>
                <td className={`border p-2 ${r.compliant ? 'text-green-600' : 'text-red-600'}`}>
                  {r.compliant ? '✔' : '✘'}
                </td>
                <td className="border p-2">{r.patches.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
